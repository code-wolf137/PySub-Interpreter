x = 0
y = 0
if x < y:
	print("x is less than y")
elif x == y:
	print("HAHAHAHAHA YAY NESTED IF STATEMENTS")
	print("This is not nested")
else:
	print("No one will see this")
