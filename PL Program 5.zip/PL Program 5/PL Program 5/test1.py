# This is test1.py
print("hello", 'world')
x = 3
print("x is equal to:", x)
y = int(input("Enter value for y:"))
print("y + 3 is:", y + 3)
print(x + y)
print(5)